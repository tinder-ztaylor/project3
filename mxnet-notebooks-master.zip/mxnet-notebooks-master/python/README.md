Notebook outline is in [outline.ipynb](outline.ipynb).
