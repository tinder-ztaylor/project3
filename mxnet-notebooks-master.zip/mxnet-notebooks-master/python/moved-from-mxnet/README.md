Moved from mxnet repo. Should be reorgnized later.
