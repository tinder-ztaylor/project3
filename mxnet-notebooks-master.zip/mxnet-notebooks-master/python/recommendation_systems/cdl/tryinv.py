import numpy as np
a = np.mat(np.ones((3,3)))
print a*a
print np.dot(a,a)
print np.multiply(a,a)
print np.sum(a)
