#Usage Notes 
First run cdl.py. In this code relu activation has been used instead of sigmoid and the code does not use pretraining
# Evaluate
To evaluate run evaluate_CDL.py. The code calculates recall@M for M from M_low to M_high. Keep the value of variable "p" same as in cdl.py. This p is used for the directory path for data fles generated. 
